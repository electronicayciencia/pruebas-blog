function [val, posi, posj] = calibrar

	% Convoluciona cada letra individual con la imagen de letras base, 
	% para ver por donde cae cada pico
	% y devuelve un array de vectores con los valores de calibrado

	% ceil(Maximo) , fila , columna

	base  = imread ('imagenes/base.png');
	base  = double(base);
	base  = base / max(max(base));

	val  = [];
	posi = [];
	posj = [];

	letras = ['ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz'];
	for c = letras
		file    = sprintf("imagenes/%s.png",c);
		indiv   = imread(file);
		indiv   = double(indiv);
		indiv   = indiv / max(max(indiv));
		result  = convoluciona(base, indiv);
	
		[i,j] = find(result == max(max(result)));

		val  = [val  ; max(max(result)) ];
		posi = [posi ; i ];
		posj = [posj ; j ];
	
		printf("%c: Max: %d, i=%d   j=%d\n",c,ceil(max(max(result))),i,j);

	end

end
