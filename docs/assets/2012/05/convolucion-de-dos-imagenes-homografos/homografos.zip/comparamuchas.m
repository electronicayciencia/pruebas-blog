function comparamuchas (cuales)
% Llama a la funcion de comparar repetidas veces con las distintas im�genes
% Almacena los resultados en un archivo
	disp("Calibrando...");
	[val, i, j] = calibrar;

	fid = fopen('OctaveOutput.txt', 'w');
	
	disp("Vale, comparando...");
	for c = cuales
		file    = sprintf("imagenes/%s.png",num2str(c));
		if (exist(file))
			printf("\nComparando el caracter %d...\n", c);

			semejanzas = comparar(num2str(c), val, i, j);
			fprintf(fid, "%s", num2str(c));
			fprintf(fid, ",%f", semejanzas);
			fprintf(fid, ",%f", max(semejanzas));
			fprintf(fid, "\n");
		end
	end

	fclose(fid);
end
