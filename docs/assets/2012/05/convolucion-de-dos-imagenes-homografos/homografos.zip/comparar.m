function [semejanza] = comparar(im, val, posi, posj)

	% Compara una letra individual con la imagen de letras base
	% un vector con los valores relativos de cada posici�n de los m�ximos

	base  = imread ('imagenes/base.png');
	base  = double(base);
	base  = base / max(max(base));

	file    = sprintf("imagenes/%s.png",im);
	indiv   = imread(file);
	indiv   = double(indiv);
	
	semejanza = [];

	% Comprobamos que el caracter no es un blanco
	% para no divir por cero.
	if ( max(max(indiv)) > 0 )
		indiv   = indiv / max(max(indiv));
		result  = convoluciona(base, indiv);

		[lim_i, lim_j] = size(result)

		for k = 1:size(val)(1)
			% En lugar de tomar el valor en el punto exacto de la calibraci�n
			% tomamos un cuadrado con tolerancia de +-1%
			% por si hubiera un ligero desplazamiento al no ser de ancho fijo
			tol = 1/100;

			min_i = floor(posi(k) * (1-tol));
			max_i = ceil (posi(k) * (1+tol));
			min_j = floor(posj(k) * (1-tol));
			max_j = ceil (posj(k) * (1+tol));

			% comprobamos los l�mites
			if (min_i < 1)     min_i = 1;     endif
			if (max_i > lim_i) max_i = lim_i; endif
			if (min_j < 1)     min_j = 1;     endif
			if (max_j > lim_j) max_j = lim_j; endif

			marco = result(min_i:max_i,min_j:max_j);
			valor = max(max(marco));
			valor = valor / val(k);

			% No permitimos parecidos superiores al 100%
			% Esto significa que es igual que la letra, y adem�s con m�s pixeles
			% El borde deber�a acabar con esto, 
			% pero si la letra es muy grande a�n pasa.
			% En algunos casos esto ser�an falsos negativos
			if ( valor > 1.00000 )
				valor = 2 - valor;
			end
			semejanza = [ semejanza ; valor ];

			printf("k=%d, posi=%d, posj=%d, i=%d:%d, j=%d:%d, semejanza=%f\n", k, posi(k), posj(k), min_i, max_i, min_j, max_j, valor);

		end

	else
		% si es un blanco, 0 parecido con cualquier otro caracter
		for i = 1:size(val)(1)
			semejanza = [ semejanza ; 0 ];
		end
	end
end

