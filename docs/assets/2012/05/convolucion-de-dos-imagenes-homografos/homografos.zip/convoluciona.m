function result = convoluciona (grande, peque)
	% se podr�a optimizar manteniendo la fft grande en memoria y no ten�endola que calcular cada vez
	grander = size(grande)(1);
	grandec = size(grande)(2);

	grande = double(grande);
	peque  = double(peque);

	grande = grande - (mean(mean(grande)) / 2);
	peque  = peque  - (mean(mean(peque)) / 2);

	grande = grande / max(max(grande));
	peque  = peque  / max(max(peque));
	
	peque = rot90(peque,2);
	
	grandefft = fft2(grande, grander, grandec);
	pequefft = fft2(peque, grander, grandec);
	conv = grandefft .* pequefft;

	result = abs(ifft2(conv));
end
