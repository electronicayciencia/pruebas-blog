#include <12F683.h>
#device adc=8

#FUSES NOWDT                 	//No Watch Dog Timer
//#FUSES INTRC_IO              	//Internal RC Osc, no CLKOUT
#FUSES HS
#FUSES NOCPD                 	//No EE protection
#FUSES NOPROTECT             	//Code not protected from reading
#FUSES NOMCLR                	//Master Clear pin used for I/O
#FUSES NOPUT                 	//No Power Up Timer
#FUSES NOBROWNOUT            	//No brownout reset
#FUSES NOIESO                	//Internal External Switch Over mode disabled
#FUSES FCMEN                 	//Fail-safe clock monitor enabled

#define PIN_SrTX  PIN_A0
#define PIN_SrRX  PIN_A1
#define PIN_T0    PIN_A2
#define PIN_Presc PIN_A3
// reservamos el 4 y el 5 para conectar un cuarzo.

#use delay(clock=12000000)
#use rs232(baud=9600,INVERT,DISABLE_INTS,parity=E,xmit=PIN_SrTX,rcv=PIN_SrRX,bits=8)  

typedef struct {
	int desb;
	long resto;
} cal_t;

void sample_freq (cal_t);
int  read_t0_presc (void);
int  atoi (char *);
cal_t calc_calib(int32);
int32 read_ee_reloj(void);
