/*
*  Frecuenc�metro sencillo para el PC.
*  El T_rise de T0 es de 10-15ns asi que la frecuencia m�xima que
*  podemos medir es de 35-50MHz.
*
*  Se usa TMR0 porque el TMR1 aunque es de 32 bits parece que s�lo
*  se recomienda hasta los 16MHz.
*
*  Reinoso G.   26-12-2010
*/
#include <frec1.h>

int t0_msb;    // desb de T0, a 50MHz durante 100ms s�lo se llega a 76.
int midiendo;  // desb de T1, amplia el rango de T1 contando desbordamientos


#int_TIMER0
void  TIMER0_isr(void) 
{
	t0_msb++;
}

#int_TIMER1
void  TIMER1_isr(void) 
{
	midiendo--;
}




void main()
{
	cal_t calib;
	int32 reloj;

	setup_adc_ports(NO_ANALOGS);
	setup_timer_0(RTCC_EXT_L_TO_H|T0_DIV_256);
	setup_timer_1(T1_INTERNAL|T1_DIV_BY_1);
	enable_interrupts(GLOBAL);

	/* Iniciando... */
	puts("Frecuencimetro. v.6/1/2011");

	/* Leer la frecuencia exacta del cuarzo:
		Para la transmision serie una leve diferencia no importa mucho
		por eso en el #use delay ponemos la frecuencia nominal.
		Pero la lectura del frecuencimetro exige una calibracion
		precisa. Por eso almacenamos la frecuencia exacta.
	*/
	reloj = read_ee_reloj();

	printf("Reloj a: %luHz\r\n", reloj);

	/* Calcular los par�metros de calibraci�n */
	calib = calc_calib(reloj);



	for(;;) {
		int32 frec;
		
		sample_freq(calib);

		frec = t0_msb;           // desbordamientos de t0
		frec<<=8;
		frec += get_timer0();    // valor de t0 al terminar
		frec<<=8;
		frec += read_t0_presc(); // valor del prescaler

		// transmitir al PC x10
		printf("F:%lu\r\n", 10*frec);
	} // for
} // main

/* Realiza una medida de frecuencia
   - Pone a cero el timer0 (eso reinicia el prescaler tambien)
   - Pone a cero el contador global (t0_msb)
   - Pone el pin T0 como entrada para que cuente
   - Espera el retardo correspondiente (desbordamientos de T1)
   - Pone el pin T0 como salida para que no cuente
   Para reducir los errores de comienzo/final de la medida ser�a
   interesante que el contador corriera libremente y anot�ramos s�lo
   la posici�n antes de empezar el retardo y despues de terminarlo.
   Pero es dificil hacer eso y leer el prescaler bien al mismo tiempo.
   En principio las medidas son de 100ms, eso da una resoluci�n de 10Hz.
*/
void sample_freq (cal_t calib) {
	output_low(PIN_T0);

	setup_timer_0(RTCC_EXT_L_TO_H|T0_DIV_256);
	enable_interrupts(INT_TIMER0);
	t0_msb = 0;
	set_timer0(0);

	/* En cuanto midiendo sea 0 paramos. */
	set_timer1(0);
	enable_interrupts(INT_TIMER1);
	midiendo = calib.desb;
	set_timer1(calib.resto);

	input(PIN_T0);
	while(midiendo);
	output_low(PIN_T0);
}


/* Lee el prescaler:
   - El prescaler no se puede leer directamente por software
   as� que lo que hay que hacer es incrementar T0 de manera controlada
   hasta que se desborde. Restando los pulsos que hemos necesitado para que
   se desborde y sabiendo que desborda a los 256 sabemos en cuanto estaba.
   - Ponemos el puerto a 0 como salida y vamos cambiando el flanco T0SE
   en cada cambio de LtoH(0) a HtoL(1) se incrementar� en 1 el prescaler.
   Podr�a no funcionar en el simulador.
   - Como ya hemos le�do el valor de T0 y del T0_msb nos da igual si se
   pierden.
*/
int read_t0_presc (void) {
	#byte OPTION_REG = 0x81
	#bit  T0SE       = OPTION_REG.4
	int impulsos;
	int t0_old;

	t0_old = get_timer0();
	output_low(PIN_T0);
	
	impulsos = 0;
	while(t0_old == get_timer0()) {
		T0SE = 0;
		T0SE = 1;
		impulsos++;
	}
	
	impulsos = 255-impulsos;
	impulsos++;
	return impulsos;
}

/* Calculamos cuantos desbordamientos tiene que hacer TMR1 y cual seria
   el resto para que con la frecuencia indicada del cuarzo se consigan
   precisamente 100ms. */
cal_t calc_calib(int32 reloj) {
	cal_t calib;
	
	reloj /= 40; // entre 4 (instr/ciclo) y entre 10 (0.1s = 100ms)
	reloj -= 60; // 60 ciclos hasta que sale del while
	calib.desb  = reloj / 65536 + 1;
	calib.resto = 65536 - (reloj % 65536);

	return calib;
}

/* Lee de la EEPROM el valor exacto de la frecuencia de oscilaci�n
   Este valor debe ser introducido por el usuario en formato Big Endian */
int32 read_ee_reloj(void) {
	int32 reloj = 0;
	int i;
	for(i=0; i<4; i++) {
		reloj <<= 8;
		reloj += read_eeprom(i);
	}
	
	// Si el usuario no ha definido el reloj, uso 12MHz por defecto.
	if (reloj == 0xFFFFFFFF) {
		reloj = 12000000;
	}
	return reloj;
}