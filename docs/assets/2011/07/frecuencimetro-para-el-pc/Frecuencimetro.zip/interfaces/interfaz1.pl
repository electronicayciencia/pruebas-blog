#!/usr/bin/perl 
#===============================================================================
#
#         FILE:  interfaz1.pl
#
#        USAGE:  ./interfaz1.pl  
#
#  DESCRIPTION:  Interfaz para el frecuencímetro 1.
#                Recoge los datos por el puerto serie (o el conversor USB) y los
#                presenta.
#
# REQUIREMENTS:  ---
#       AUTHOR:  Reinoso Guzman 
#      VERSION:  1.0
#      CREATED:  30/12/10 14:21:05
#===============================================================================

use strict;
use warnings;

use Device::SerialPort 0.12;

$| = 1;

my $PORT      = "/dev/ttyUSB0";

my $s_port = Device::SerialPort->new ($PORT) || die "Can't Open $PORT: $!";
$s_port->baudrate(9600);
$s_port->parity("none");
$s_port->databits(8);
$s_port->handshake("none");
$s_port->write_settings;

$s_port->purge_all();
$s_port->purge_rx;

open( DEV, "<$PORT" ) || die "Error abriendo $PORT: $_\n";

my $linea;
while($linea = <DEV>) {
	#print time."\t".$linea;

	my ($valor) = $linea =~ /F:(\d+)/;
	next unless $valor;

	# Redondeo
	$valor = int($valor/100 + 0.5);	# Redondeo hasta 100Hz
	$valor = $valor / 10;			# Decimales a partir de kHz
	
	my $resul = $valor;

	# Lo quitamos si es cero
	next unless $resul;

	# Hasta 100Hz, un lugar decimal
	$resul = sprintf("%.1f", $resul);
	# Expresarlo con separador de miles
	# (esta linea es de 'Mastering regular expressions')
	1 while ($resul =~ s/^(-?\d+)(\d{3})/$1 $2/);

	print time."\t".$resul."\n";
}



