% Leer abajo del todo

Fs = 882;

Fc = 90;  % pasabajos: que corte a 90Hz
Fcn = Fc / Fs;

FR = [1    repmat(1,1, 2*Fcn * (Fs/2) )     repmat(0,1, (1-2*Fcn)*Fs/2)];

% bandas suprimidas, 50Hz y 100Hz
Fsup1 = 100; Fsup1n = Fsup1 / Fs;
Fsup2 = 200; Fsup2n = Fsup2 / Fs;

FR(Fsup1n * (Fs/2)) = 0;
FR(Fsup1n * (Fs/2) + 1) = 0;
FR(Fsup1n * (Fs/2) - 1) = 0;
FR(Fsup1n * (Fs/2) + 2) = 0;
FR(Fsup1n * (Fs/2) - 2) = 0;
FR(Fsup1n * (Fs/2) + 3) = 0;
FR(Fsup1n * (Fs/2) - 3) = 0;

FR(Fsup2n * (Fs/2)) = 0;
FR(Fsup2n * (Fs/2) + 1) = 0;
FR(Fsup2n * (Fs/2) - 1) = 0;

FRx = FR; for i = Fs/2+2:Fs; FRx(i) = FR(Fs+1-i); end

kernel = (fftshift (real(fft(FRx))));
NKernel = 100; filtro = kernel((Fs/2+1)-NKernel/2 : (Fs/2+1)+NKernel/2) .* blackman(NKernel+1)'; filtro = filtro / sum(filtro);

freqz(filtro,1,512,Fs);



% --------------------------------------------------------------------------
% Pasos para hacer un filtro FIR personalizado

Fs = 1000;   % frec de muestreo

% Si quiero que corte a 200Hz, tendr�a que poner 0.2*Fs, o sea 0.4*Fs/2

% Respuesta en Frecuencia (hasta Fs/2+1 puntos):
FR = [1    repmat(1,1, Fs/2*0.4 )     repmat(0,1, Fs/2*(1-0.4))];
%    0Hz

% Dominio extendido sim�tricamente
FRx = FR; for i = Fs/2+2:Fs; FRx(i) = FR(Fs+1-i); end

% el kernel del filtro
kernel = (fftshift (real(fft(FRx))));

% la simetr�a del kernels est� en Fs/2 + 1

NKernel = 300;   % puntos del kernel (debe ser par para que haya simetr�a)

% uso ventana de Hamming o de Blackman
filtro = kernel((Fs/2+1)-NKernel/2 : (Fs/2+1)+NKernel/2).*blackman(NKernel+1)';

filtro = filtro / sum(filtro);   % normalizo para que en DC la ganacia sea 0dB

freqz(filtro,1,512,Fs);
