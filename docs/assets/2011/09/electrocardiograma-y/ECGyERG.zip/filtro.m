# queda hacer la funciona ECGfiltra por un lado y ECGgrafica por otro

# Script de octave para filtrar el archivo
# a es el vector con los datos


# normalizamos
t=max(abs(min(a)),max(a));
a=a./t;

# obtenemos la FFT:
b = fft(a);
c = b(1:44101);
# trabajo sobre una copia
d = c;

# la frecuencia
f=(0:0.5:22050)';

# graficamos hasta 1kHz
#grid;
#plot(f(1:2000),abs(c(1:2000)));

# quitamos la red y sus arm�nicos:
for ind=101:100:22050;
	d(ind)=0;
	d(ind-1)=d(ind-1)/4;
	d(ind+1)=d(ind+1)/4;
end

# filtro gaussiano paso bajo
function gauss = gauss(x,a,b,c)
	gauss = a*exp(-(x-b).**2/c**2);
end

d = d .* gauss(f,1,10,15);

# obtenemos la forma de onda (invertida)
e = -real(ifft(d));

# escalas temporales
sta = 0:2/88201:2';
ste = 0:2/44100:2';

# graficamos
figure;
axis ("labelx", "tic");
multiplot(1,2);
subplot(2,1,1);
plot(sta,a,";;");
#title("Se�al original");
grid("on");
subplot(2,1,2);
plot(ste,e,";;");
#title("Se�al filtrada");
grid("on");



---------

La cte de tiempo de la entrada de la tarjeta es 0.02168
la f de transfer es:
function ftrans = ftrans(s)
	tau = 0.02168;
	ftrans = s.*tau./(1+s.*tau);
end

la funci�n inversa es (s en Hz):
function ftransinv = ftransinv(s)
	tau = 0.02168;
	ftransinv = (1+s.*tau)./(s.*tau);
end

# hacer que cuando f=0 => finv = 1
# vale para aplicarlo al ECG (bajas frec), pero no al EEG o al ERG

para desfiltrar el filtro de la SB:
aunque en principio no hace falta con lo que sale sale bien
e = [ d(1:7); d(8:44101) .* abs(ftransinv(2*pi*f(8:44101)*i))];


OJO:
he abierto la tarjeta y tiene un condensador de 10uF 25V y una resistencia
de 220k a tierra. M�s una de 1k para protejer la entrada.
