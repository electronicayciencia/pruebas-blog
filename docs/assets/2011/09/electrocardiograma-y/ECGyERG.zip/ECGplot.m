function ECGplot(a,b,c)
# grafica arriba a y abajo b
# c es para invertirla o no
# escalas temporales
	sta = 0:2/88201:2';
	ste = 0:2/44100:2';

# graficamos para comparar
	figure;
	axis ("labelx", "tic");
	multiplot(1,2);
	subplot(2,1,1);
	plot(sta,a,";;");
	#title("Se�al original");
	grid("on");
	subplot(2,1,2);
	plot(ste,c*b,";;");
	#title("Se�al filtrada");
	grid("on");
end