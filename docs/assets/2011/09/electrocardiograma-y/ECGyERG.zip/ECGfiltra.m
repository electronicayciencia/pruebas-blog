function [ c ] = ECGfiltra( a, sr )
	% normalizamos
	a=a/max(abs(a));
	
	% obtenemos la FFT:
	b  = fft(a);       % b es la fft de a
	np = numel(b) / 2; % np numero de puntos;
	b  = b(1:np);      % truncamos la fft
	
	% cancelamos la red y sus arm�nicos:
	for i=101:100:sr/2; % 100 es para este caso, ver texto*
		b(i) = (b(i-1) + b(i+1)) / 2;
	end
	
	f_bw  = (sr/2 / np);
	f = [0:f_bw:sr/2-f_bw];

	b = b .* gauss(f',1,0,40);
	
	% reobtenemos la forma de onda filtrada
	b = [b ; 0 ; conj(flipdim(b(2:np)))]; % completamos la FFT
	c = real(ifft(b)); % nos quedamos s�lo la parte real
	c = c/max(abs(c)); % normalizamos
end

# filtro gaussiano paso bajo
function gauss = gauss(x,a,b,c)
	# a: multiplicador
	# b: media
	# c: anchura
	gauss = a*exp(-(x-b).**2/c**2);
end

