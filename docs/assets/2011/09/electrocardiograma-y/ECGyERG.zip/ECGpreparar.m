% Calcula algunas variables en funcion de la señal de entrada
% para simplificar a la hora de hacer los gráficos.
% Para no complicarnos, tanto el numero de muestras como la frecuencia
% de muestreo deben der pares.
function [tiempos, espectro, frecuencias] = ECGpreparar (senal, sampl_rate)
	% -- Tiempo --
	t_inicio = 0;
	t_npuntos = numel(senal);
	t_fin = t_npuntos / sampl_rate;

	t_bw    = (t_fin-t_inicio)/t_npuntos;
	tiempos  = [t_inicio:t_bw:t_fin-t_bw];


	% -- Frecuencias --
	espectro  = fft(senal);
	f_npuntos = numel(espectro) / 2;
	f_inicio  = 0;
	f_fin     = sampl_rate/2;

	f_bw  = (f_fin-f_inicio)/f_npuntos;
	frecuencias = [f_inicio:f_bw:f_fin-f_bw];

	% Cortamos la parte simétrica de la FFT
	% Y normalizamos el modulo
	espectro = abs(espectro(1:f_npuntos));
	espectro /= max(espectro);
end

