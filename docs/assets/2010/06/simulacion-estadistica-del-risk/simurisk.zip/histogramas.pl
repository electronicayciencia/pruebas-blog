#!/usr/bin/perl 
#===============================================================================
#  DESCRIPTION:  Llama a gnuplot para dibujar el caso que se pida.
#                Escribe la web correspondiente.
#                Escribe la web inicial.
#===============================================================================

use strict;
use warnings;
use Storable qw(retrieve);
use List::Util qw(max min);

my $dir_img  = "img";
my $dir_html = "html";
my $hashref  = retrieve('datos_compactados.raw') || die "Imposible leer los datos: $!.\n";
my %hash_general = %$hashref;


foreach my $caso (sort keys %hash_general) {
	my ($atacantes, $defensores) = $caso =~ /a(\d+)d(\d+)/;

	print "Graficando el caso $caso...\n";
	histograma($caso);
	paginaweb($caso);
}

paginainicial(16,16);


# Escribe la portada y el selector de casos.
# Recibe el n�meor m�ximo de atacantes y de defensores.
sub paginainicial {
	my ($max_a, $max_d) = @_;
	my $filename = "$dir_html/index.html";
	my $tablaEstados;

	$tablaEstados = sprintf "<table class='selEstados'>\n";
	
	foreach my $a (1..$max_a) {
		$tablaEstados .= sprintf "<tr>\n";
		foreach my $d (1..$max_d) {
			my $caso = sprintf ("a%03dd%03d", $a, $d);
			my $ganadas  = $hash_general{$caso}{resultado}{1} || 0;
			my $perdidas = $hash_general{$caso}{resultado}{0} || 0;
			my $batallas = $ganadas + $perdidas;
			my $probganar = sprintf("%.0f", 100*$ganadas/$batallas);
			my $probperder = 100 - $probganar;

			my $class;
			$probganar > 75  and $class = "ganaA";
			$probganar <= 75 and $probganar >= 25 and $class = "empate";
			$probganar < 25  and $class = "ganaD";
			$tablaEstados .= sprintf "<td><a class='$class' href=$caso.html>$a / $d</td>\n";
		}
		$tablaEstados .= sprintf "</tr>\n";
	}
	$tablaEstados .= sprintf "</table>\n";

		open my $fh, "> $filename";
	print $fh <<eof ;
<html>
<head>
	<title>Simulaci�n de Risk. Inicio.</title>
	<META NAME="Author" CONTENT="Reinoso G. electronicayciencia\@gmail.com">
	<link rel="stylesheet" type="text/css" href="class_portada.css" />
</head>

<body>
	<h1>Bienvenido a la simulaci�n estad�stica de Risk.</h1>
	<h2>Esta p�gina esta explicada en el blog <a href='http://electronicayciencia.blogspot.com'>electronicayciencia</a>.</h2>
	<h3>Por favor, selecciona el estado inicial de la batalla <i>Atacantes / Defensores</i>.<h3>
	<center>
	$tablaEstados
	</center>
</body>
</html>
eof

	close $fh;


}


# Escribe una p�gina web con el histograma centrado y los enlaces
# de ganar o perder.
sub paginaweb {
	my $caso = shift;
	my $filename = "$dir_html/$caso.html";

	my ($atacantes, $defensores) = $caso =~ /a(\d+)d(\d+)/;
	$atacantes += 0; $defensores += 0; # Transformar a num�rico.
	
	my $ganadas  = $hash_general{$caso}{resultado}{1} || 0;
	my $perdidas = $hash_general{$caso}{resultado}{0} || 0;
	my $batallas = $ganadas + $perdidas;
	my $probganar = sprintf("%.0f", 100*$ganadas/$batallas);
	my $probperder = 100 - $probganar;

	my $td_ganar  = $probganar > 50  ? "$probganar% de posibilidades de ganar"   : "";
	my $td_perder = $probganar <= 50 ? "$probperder% de posibilidades de perder" : "";

	# Ver el estado siguiente
	my $bajas = min(2, $atacantes, $defensores);

	my $estado_gana_A;
	my $estado_gana_D;
	my $estado_empate;

	if ($defensores-$bajas > 0) {
		$estado_gana_A = sprintf ("a%03dd%03d", $atacantes, $defensores-$bajas);
	} else {
		$estado_gana_A = "gana_Atacante";
	}

	if ($atacantes-$bajas > 0) {
		$estado_gana_D = sprintf ("a%03dd%03d", $atacantes-$bajas, $defensores);
	} else {
		$estado_gana_D = "gana_Defensor";
	}

	if ($atacantes-1 > 0 and $defensores-1 > 0) {
		$estado_empate = sprintf ("a%03dd%03d", $atacantes-1, $defensores-1);
	} elsif ($atacantes-1 > 0 and $defensores-1 == 0) {
		$estado_empate = "gana_Atacante";
	} elsif ($atacantes-1 == 0 and $defensores-1 > 0) {
		$estado_empate = "gana_Defensor";
	} else {
		$estado_empate = "no_puede_darse";
	}


	open my $fh, "> $filename";
	print $fh <<eof ;
<html>
<head>
	<title>Simulaci�n de Risk. Caso $atacantes atacantes contra $defensores defensores.</title>
	<META NAME="Author" CONTENT="Reinoso G. electronicayciencia\@gmail.com">
	<link rel="stylesheet" type="text/css" href="class_estados.css" />
</head>

<body>
	<center>
	<div class="histograma">
		<img class="histograma" src="../$dir_img/hist_$caso.png">
	</div>

	<div class="probganar">
		<table width="100%">
			<tr>
			<td class="roja" width="$probganar%">$td_ganar</td><td width="$probperder%">$td_perder</td>
			</tr>
		</table>
	</div>
	</center>

 	<div class="ganaA">
		<a class="ganaA" href="$estado_gana_A.html">Gana el ATACANTE</a>
	</div>
 	<div class="empate">
 		<a class="empate" href="$estado_empate.html">Empate</a>
	</div>
 	<div class="ganaD">
		<a class="ganaD" href="$estado_gana_D.html">Gana el DEFENSOR</a>
	</div>
</body>
</html>
eof

	close $fh;
}



# Dibuja los histogramas, utiliza el hash global %hash_general y la variable $dir.
# Recibe un par�metro que es el caso.
sub histograma {
	my $caso = shift;
	my $filename = "$dir_img/hist_$caso.png";
	my ($atacantes, $defensores) = $caso =~ /a(\d+)d(\d+)/;
	$atacantes += 0; $defensores += 0;
	my $batallas;
	my $ganadas;
	my $perdidas;
	my $probganar;
	my $hist_bajas_a = "";
	my $hist_bajas_d = "";
	my $hist_tiradas = "";

	for (sort {$a <=> $b} keys %{$hash_general{$caso}{bjs_ata}}) {
		next if $_ == $atacantes;
		$hist_bajas_a .= "\"  $_\", ".$hash_general{$caso}{bjs_ata}{$_}."\n";
	}

	for (sort {$a <=> $b} keys %{$hash_general{$caso}{bjs_def}}) {
		next if $_ == $defensores;
		$hist_bajas_d .= "\"  $_\", ".$hash_general{$caso}{bjs_def}{$_}."\n";
	}
	
	for (sort {$a <=> $b} keys %{$hash_general{$caso}{tiradas}}) {
		$hist_tiradas .= "\"  $_\", ".$hash_general{$caso}{tiradas}{$_}."\n";
	}
	
	$ganadas  = $hash_general{$caso}{resultado}{1} || 0;
	$perdidas = $hash_general{$caso}{resultado}{0} || 0;
	$batallas = $ganadas + $perdidas;
	$probganar = sprintf("%.0f%%", 100*$ganadas/$batallas);
	
	my $file;
	open $file, "| gnuplot";
	print $file <<eof ;
set terminal png nocrop enhanced size 700,500 transparent
se output  "$filename"
set multiplot layout 3, 1 title "Caso de $atacantes contra $defensores ($probganar de posibilidades de que gane el atacante)"
unset key
se format y '\%g\%\%'
set ytics nomirror
unset xtics
set border 3
set xtics norotate nomirror
set style fill solid
se grid y
set obj 20 rect from graph 0, graph 0 to graph 1, graph 1 fs solid 0.1 border -2 fc rgb "#000000" behind

set ylabel "P. bajas atacante\\n"
plot "-" using (\$2/$ganadas)*100:xtic(1) with histograms lc rgb 'red'
$hist_bajas_a
e

set ylabel "P. bajas defensor\\n"
unset xtics
set xtics norotate nomirror
plot "-" using (\$2/$perdidas)*100:xtic(1) with histograms lc rgb 'blue'
$hist_bajas_d
e

set ylabel "P. tiradas\\n"
unset xtics
set xtics norotate nomirror
plot "-" using (\$2/$batallas)*100:xtic(1) with histograms lc rgb '#00a000'
$hist_tiradas
e

eof

	close $file;
}


__END__

set terminal png nocrop enhanced size 700,600
se output  "prueba.png"
set multiplot layout 3, 1 title "Caso 13 vs. 12"
unset key
se format y '%g%%'
set ytics nomirror
unset xtics
set border 3
set xtics norotate nomirror
set style fill solid
se grid y
set obj 20 rect from graph 0, graph 0 to graph 1, graph 1 fs solid 0.1 border -2 fc rgb "#000000" behind

set ylabel "P. bajas atacante\n"
plot "/tmp/gg" using ($2/200000)*100:xtic(1) with histograms lc rgb 'red'

set ylabel "P. bajas defensor\n"
unset xtics
set xtics norotate nomirror
plot "/tmp/gg1" using ($2/200000)*100:xtic(1) with histograms lc rgb 'blue'

set ylabel "P. tiradas\n"
unset xtics
set xtics norotate nomirror
plot "/tmp/gg2" using ($2/200000)*100:xtic(1) with histograms lc rgb '#00a000'

exit

