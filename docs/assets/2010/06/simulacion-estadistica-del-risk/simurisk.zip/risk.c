/* Reescritura en C de RISK.BAS 
 *
 * Reinoso G.		08/06/2010
 */


/* En los atacantes, tener en cuenta que si se habla de n atacantes es porque en el territorio hay
 * n+1 ya que un ejercito s�lo no puede atacar. */
#define MAX_ATACANTES 16
#define MAX_DEFENSORES 16


#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>

typedef struct {
	int atacantes;
	int defensores;
	int lineas;
} t_estado;

typedef struct {
	int bajas_ataque;
	int bajas_defensa;
	int tiradas; // cuantas tiradas son necesarias
	int ganada; // 1: gana el atacante, 0: gana el defensor
} t_batalla;


/* FUNCIONES PARA OBTENER EL ESTADO ************************************************/
/***********************************************************************************/

/* Recibe el nombre de un archivo
 * Si el archivo existe devuelve el n�mero de l�neas que tiene
 * Si no existe lo crea y devuelve 0
 * Si no pudiera crearlo, enconces sale 
 * OJO: Las l�neas que pasen de 80 car�cteres las cuenta varias veces. */
int numberOfLines_create (char *filename) {
	int count = 0;
	char line[80];
	FILE *fp = fopen (filename, "r");

	if (!fp) {
		fp = fopen(filename, "w");
		if (!fp) {
			printf ("Error al crear %s.", filename);
			exit(1);
		}
		fclose(fp);
		return 0;
	}
	
	while ( fgets(line, 80, fp) != NULL) count++;
	close(fp);
	return count;
}


/* Rellena la matriz de estado con el estado actual de la simulaci�n
 * Devuelve el n�mero de estados, que es el resultado de MAX_DEFENSORES * MAX_ATACANTES */
int set_estados(t_estado *estado_actual) {
	int a;	// Atacantes
	int d;	// Defensores
	int n;	// N�mero del estado
	char filename[13]; // Nombre del fichero a???d???.lst\0 

	n = -1;

	for (a = 1; a <= MAX_ATACANTES; a++) {
		for (d = 1; d <= MAX_DEFENSORES; d++) {
			n++;
			snprintf(filename, 13, "a%03dd%03d.lst", a, d);
			
			estado_actual[n].atacantes  = a;
			estado_actual[n].defensores = d;
			estado_actual[n].lineas = numberOfLines_create(filename);
		}
	}

	return n;
}

/* Devuelve el estado siguiente que se debe simular para igualar el n�mero en todas.
 * Se basa en el que tenga menor n�mero de l�neas.
 * Si todos tienen el mismo n�mero se empieza por el m�s bajo. */
int next_estado (t_estado *estado_actual, int nestados){
	int next = 0;
	int i;
	int min_lineas = estado_actual[0].lineas;

	/* Obtener el estado que tiene el m�nimo n�mero de l�neas */
	for (i = 0; i <= nestados; i++) {
		int lineas = estado_actual[i].lineas;
		if (lineas < min_lineas) {
			next = i;
			min_lineas = lineas;
		}
	}

	return next;
}

/* Anota el resultado en una l�nea del archivo correspondiente.
 * Tambi�n incrementa en uno la cantidad del l�neas del estado del que se trate. */
void anotarResultado (t_estado *estado, t_batalla resultado) {
	FILE *fp;
 	char filename[13]; // Nombre del fichero a???d???.lst\0 
	int j;
	
	snprintf(filename, 13, "a%03dd%03d.lst", estado->atacantes, estado->defensores);
	fp = fopen(filename, "a");
	if (!fp) {
		printf("\nImposible abrir el archivo %s: %s\n", filename, strerror (errno));
		exit(1);
	}

	j = fprintf(fp, "%d\t%d\t%d\t%d\n", 
		resultado.bajas_ataque,
		resultado.bajas_defensa,
		resultado.tiradas,
		resultado.ganada);
	
	fclose(fp);
	
	estado->lineas++;
}


void usage (void) {
	puts("Uso: simurisk <numero>");
	puts("     numero: es el n�mero de simulaciones requeridas por cada estado");
	exit(2);
}


/* FUNCIONES PARA SIMULAR LAS TIRADAS **********************************************/
/***********************************************************************************/

/* Genera un n�mero aleatorio entre 1 y 6 */
int dado (void) {
	int j;
	j = 1 + (int)( 6.0 * rand() / ( RAND_MAX + 1.0 ) );
	return j;
}

/* Intercambia dos valores enteros */
void swap(int *x, int *y)
{
	int	t;
	t = *x;	/*	*x is value pointed to by x	*/
	*x = *y;
	*y = t;
}

/* Simula una tirada de dados
 * Devuelve: -n si gana el defensor y el atacante pierde n ej�rcitos
 *            0 si empatan y cada jugador pierde un ej�rcito
 *           +n si gana el atacante y el defensor pierde n ej�rcitos */ 
int tirada (int at, int def) {
	int a1, a2, a3; // dados del atacante (rojos)
	int d1, d2;     // dados del defensor (azules)
	int n;
	n = a1 = a2 = a3 = d1 = d2 = 0;

	a1 = dado();    // siempre al menos un ej�rcito atacante
	if (at >= 2) a2 = dado();
	if (at >= 3) a3 = dado();

	d1 = dado();
	if (def >= 2) d2 = dado();

	/* Ordenar los dados para comparar, de mayor a menor */
	if (a3 > a1) swap(&a3, &a1);
	if (a3 > a2) swap(&a3, &a2);
	if (a2 > a1) swap(&a2, &a1);
	
	if (d2 > d1) swap(&d2, &d1);

	
	/* Comparaci�n */
	if (a1 <= d1) {
		n--;
	}
	else {
		n++;
	}

	if (a2 && d2) {
		if (a2 <= d2) {
			n--;
		}
		else {
			n++;
		}
	}

	//printf ("Dados atacante: %d, %d, %d; dados defensor %d, %d; resultado %d.\n", a1, a2, a3, d1, d2, n);
	return n;
}


/* Simula una batalla entre a atacantes y d defensores
 * Devuelve el resultado en un tipo t_batalla */
t_batalla batalla(int a, int d) {
	t_batalla resultado;
	resultado.bajas_defensa = resultado.bajas_ataque = resultado.tiradas = 0;

	while (a > 0 && d > 0) {
		int bajas = tirada(a, d);
		resultado.tiradas++;
		if (bajas > 0) {
			d -= bajas;
			resultado.bajas_defensa += bajas;
		}
		else if (bajas < 0) {
			a -= (-bajas);
			resultado.bajas_ataque += (-bajas);
		}
		else { // bajas == 0
			a--;
			d--;
			resultado.bajas_ataque++;
			resultado.bajas_defensa++;
		}
		//printf("Atacantes: %d, Defensores %d\n", a, d);
	}

	if (d == 0) {
		resultado.ganada = 1;
	}
	else {
		resultado.ganada = 0;
	}

	return resultado;
}










/* FUNCI�N PRINCIPAL ***************************************************************/
/***********************************************************************************/

int main (int argc, char **argv) {
	t_estado estado_actual[MAX_DEFENSORES * MAX_ATACANTES];
	int nestados;
	int i;
	unsigned int batallas = 0;
	unsigned int num_stop; // batallas en cada estado para detener la simulaci�n

	srand ( (unsigned)time ( NULL ) );

	if (argc != 2) {
		usage();
		exit(0);
	} 
	else {
		num_stop = atoi(argv[1]);
		if (!num_stop)
			num_stop = 1000;
	}

	puts("C�lculo de probabilidades en las jugadas de Risk.");
	printf("Se han pedido un m�ximo de %d batallas en cada estado.\n", num_stop);
	
	puts("Comprobando el estado actual de los ficheros...");
	nestados = set_estados(estado_actual);
	
/*	for (i = 0; i <= nestados; i++) {
		printf("Estado %d -> A = % 3d,  D = % 3d,   Lineas = %d\n", 
			i,
			estado_actual[i].atacantes,
			estado_actual[i].defensores,
			estado_actual[i].lineas);
	}
*/
	
	puts("\nComienza la simulaci�n.\n");
	while(1) {
		int next       = next_estado(estado_actual, nestados);
		int atacantes  = estado_actual[next].atacantes;
		int defensores = estado_actual[next].defensores;

		if (next == 0) {
			if (estado_actual[0].lineas % 100 == 0) {
				printf("\033[1K\015Llevamos %d batallas por cada estado.", estado_actual[0].lineas);
				fflush(stdout);
			}

			if (estado_actual[0].lineas >= num_stop) {
				puts("\nSimulaci�n completada.");
				exit(0);
			}
		}

		t_batalla resultado = batalla(atacantes, defensores);

		/*
		printf("Batalla %d vs. %d: bajas atacante %d, bajas defensor %d, tiradas %d, ganada %d\n", 
			atacantes,
			defensores,
			resultado.bajas_ataque,
			resultado.bajas_defensa,
			resultado.tiradas,
			resultado.ganada);
		*/
		anotarResultado(&estado_actual[next], resultado);
		batallas++;

	}

	return 0;
}


