#!/usr/bin/perl 
#===============================================================================
#         FILE:  compacta_datos.pl
#
#  DESCRIPTION:  Obtiene un recuento de los datos brutos para que sea m�s f�cil de analizar.
#===============================================================================

use strict;
use warnings;
use File::Basename;
use Storable qw(store);

my $dir = "simul";
my %hash_general;

open my $file_txt, "> datos_compactados.txt";

my $ficheros = `\\ls -1 $dir/a???d???.lst`;
foreach my $fichero (split /\n/, $ficheros) {
	my %hash_estado;
	my $linea;

	print "Compactando el archivo $fichero.\n";

	open my $fh, "< $fichero";
	while ($linea = <$fh>) {
		chomp $linea;
		my ($b_at, $b_def, $tiradas, $ganada) = split /\s+/, $linea;
		
		$hash_estado{bjs_ata}{$b_at}++;
		$hash_estado{bjs_def}{$b_def}++;
		$hash_estado{tiradas}{$tiradas}++;
		$hash_estado{resultado}{$ganada}++;
	}
	close $fh;


	my $estado = basename($fichero, '.lst');
	$hash_general{$estado} = \%hash_estado;


	foreach my $que (sort keys %hash_estado) {
		print $file_txt "$estado.$que\t";
		my $max = (sort {$a <=> $b} keys %{$hash_estado{$que}})[-1];
		print $file_txt ((defined $hash_estado{$que}{$_} ? $hash_estado{$que}{$_} : 0) . " ") for (0..$max);
		print $file_txt "\n";
	}
	print $file_txt "\n";
}

close $file_txt;
print "Terminado. Guardando los datos.\n";
store(\%hash_general, 'datos_compactados.raw');


