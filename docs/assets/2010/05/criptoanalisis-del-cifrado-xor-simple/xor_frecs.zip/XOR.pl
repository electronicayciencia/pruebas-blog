#!/usr/bin/perl -w

# Estudio del cifrado XOR con clave c�clica.    28/05/2008.
# 
#
# Aplica XOR al archivo que se le pase
#

use strict;
use warnings;
use File::Basename;


print "-= Estudio de Cifrado =-\n";

my $clave;
my $texto;
my $archivo;

$archivo = $ARGV[0] or die "Uso: $0 fichero\n";
open(FH, $archivo)  or die "no puedo abrir $archivo: $!\n";
binmode(FH);
read(FH, $texto, 8192); # Truncamos en 8k.
close FH;

while (1) {
	print "Introduce la clave de cifrado: ";
	$clave = <STDIN>;
	chomp $clave;
	last if length $clave >= 2;
	print "La longitud de la clave debe ser mayor de 2. ";
}

my $cifrado = &cifraXOR($clave, $texto);

my $base = basename($archivo, '.txt');
open(FH, "> ${base}_XOR_$clave") or die "No puedo escribir en ${base}_XOR_$clave: $!";
binmode(FH);
print(FH $cifrado);
close FH;



sub cifraXOR {
	my ($clave, $texto) = @_;
	my $cifrado = "";
	my $l = length($texto) - 1;
	
	for my $i (0..$l) {
		my $ltxt = substr $texto, $i, 1;
		my $lkey = substr $clave, $i % length $clave, 1;
	
		my $lcif = chr(ord($ltxt) ^ ord($lkey));
		$cifrado .= $lcif;
	}
	return $cifrado;
}

