#!/usr/bin/perl

# Estudio del cifrado XOR con clave c�clica.    28/05/2008.
# 
# Metodo para averiguar la longitud de la clave:
# Aplica un desplazamiento y cuenta cuantos caracteres del texto desplazado coinciden con el texto
# sin desplazar. Obtiene el resultado en tanto por ciento.
#
# Filtra los resultados que hayan obtenido m�s de la media m�s 4 veces la varianza. Se espera que
# haya una subida cuando el desplazamiento sea m�ltiplo de la longitud de la clave.
#
# Si hacemos una regresi�n lineal (y = k*x) con esos valores, la pendiente de la recta k indicar� 
# cual es la longitud de la clave que quer�amos. Y el coeficiente de correlaci�n r ser� mayor cuanto
# mejor sea el ajuste y por tanto la estimaci�n de la longitud.
#
# Una vez sabida la longitud, el romper la clave es cuesti�n de conocer las frecuencias relativas
# de los caracteres en el texto plano.
#

use warnings;
use strict;
use List::Util qw[min max];
use Statistics::Descriptive;

print "-= Estudio de Cifrado =-\n";

my $cifrado;
my $xorfile = $ARGV[0]        or die "Uso: $0 fichero\n";
open(FH, $xorfile)            or die "No puedo abrir $xorfile: $!";
binmode(FH);
read(FH, $cifrado, 4*1024);
close FH;



# ============== Primera parte: averiguar la longitud de la clave =====
# =====================================================================
#
my @results; # resultados de las coincidencias
my $stat = Statistics::Descriptive::Full->new();

my $n = (length $cifrado) / 2;
for my $i (1..$n) {
	my $coin = &coincidencias($cifrado, substr($cifrado, $i));
	printf "Desplazamiento: %d caracteres, grado de coincidencia %4f%%\n", $i,  $coin / length(substr($cifrado, $i)) * 100;
	push @results, $coin / length(substr($cifrado, $i)) * 100;
}
$stat->add_data(@results);

my $mean = $stat->mean();
my $var  = $stat->variance();

print "\nFiltrando resultados (coincidencia > media + n * varianza):\n";
print "  Media estad�stica de los resultados: ". $mean . "\n";
print "  Varianza: ". $var . "\n";

# Se hace la regresi�n bajando cada vez m�s el offest hasta que converja
my $offset = 4;
my $m;
my $r;
do {
	my $max  = $mean + $offset * $var;
	#print "Contamos los que sobrepasen $max\n";

	my @results2 = (); # las posiciones de los @result que supperen el umbral.
	my $i = 1;
	foreach (@results) {
		$_ > $max and push @results2, $i;
		$i++;
	}

	if ( scalar @results2 > 3 ) {
		$, = "\n";
		#print @results2;

		my $stat2 = Statistics::Descriptive::Full->new();
		$stat2->add_data(@results2);
		(undef, $m, $r, undef) = $stat2->least_squares_fit();
		
		printf "Con n = %3.2f (%d resultados) longitud obtenida %3.2f -> r = %5f\n", $offset, scalar @results2 , $m, $r;
		$m < 0.1 and die "No puedo determinar la longitud de la clave: el algoritmo converge a 0.\n";
	}

	$offset < 0.02 and die "No puedo determinar la longitud de la clave: insuficiente informaci�n o no es XOR.\n";

	$offset *= 0.9;
} until (defined $r and $r > 0.999999);

print "\nLa longitud de la clave parece que es $m.\n";
print "\nPulsa enter para continuar..."; <STDIN>;




# ============== Segunda parte: adivinar la clave =====
# =====================================================
#
# Nos basamos en frecuencias de aparici�n para el idioma ingl�s.
# Puede no funcionar bien para otros idiomas.
my $longclave = $m;
my %columnas;
my $clave = "";

# el texto ficfrado sigue en $cifrados.
# Separarlo en tantas columnas como caracteres tiene la clave.
my $l = length($cifrado);
for my $i (1..$l) {
	my $char = ord(substr $cifrado, $i-1, 1);
	push @{$columnas{($i % $longclave) == 0 ? $longclave : $i % $longclave}}, $char;
}

# Ahora todos los caracteres de la columna est�n cifrados con el mismo caracter de la clave.
# Contamos la frecuencia relativa de cada uno
print "\nEstudio de las frecuencias de aparici�n para obtener la clave.\n";

foreach my $col (1..$longclave) {
	my @col = @{$columnas{$col}};
	my %frecs;
	$frecs{$_}++ foreach @col;

	# Ordenamos de mayor a menos frecuencia
	foreach my $key ( sort { $frecs{$b} <=> $frecs{$a} } keys %frecs ) {
		my $charclave = $key ^ ord(' '); # asumo que el espacio es el caracter m�s frecuencia
		if ($charclave =~ /\w/) {        # asumo que la clave es alfanum�rica
			printf "El caracter de la clave para la columna %d podr�a ser '%c'.\n", $col, $charclave;
			$clave .= chr($charclave);
			last;
		}
		print $key . "->".  $frecs{$key} ."\n";
	}
}

print "\nClave encontrada: $clave\n\n";

exit (0);


# ============== Rutinas de apoyo =====
# =====================================


sub cifraXOR {
	my ($clave, $texto) = @_;
	my $cifrado = "";
	my $l = length($texto) - 1;
	
	for my $i (0..$l) {
		my $ltxt = substr $texto, $i, 1;
		my $lkey = substr $clave, $i % length $clave, 1;
	
		my $lcif = chr(ord($ltxt) ^ ord($lkey));
		$cifrado .= $lcif;
	}
	return $cifrado;
}


sub coincidencias {
	my ($a, $b) = @_;
	my $l = min(length $a, length $b) - 1;

	my $coincidencias = 0;
	for my $i (0..$l) {
		$coincidencias++ if substr($a, $i, 1) eq substr($b, $i, 1);
	}
	return $coincidencias;
}


