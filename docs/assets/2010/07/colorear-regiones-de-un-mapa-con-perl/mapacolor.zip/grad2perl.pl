#!/usr/bin/perl 

use strict;
use warnings;

my %l;
while (<>) {
	s/^\s+//g;
	s/\s+$//g;
	my @l = split /\s+/;
	$l{$l[0]} = sprintf("[%3s,%3s,%3s]", $l[1], $l[2], $l[3]);
	$l{$l[4]} = sprintf("[%3s,%3s,%3s]", $l[5], $l[6], $l[7]);
	$l{$l[8]} = sprintf("[%3s,%3s,%3s]", $l[9], $l[10], $l[11]);
	$l{$l[12]} = sprintf("[%3s,%3s,%3s]", $l[13], $l[14], $l[15]);
}

for(my $i = 0; $i <= 255; $i += 4) {
	printf ('%s, %s, %s, %s,'."\n", $l{$i}, $l{$i+1}, $l{$i+2}, $l{$i+3});
}

