#===============================================================================
#         FILE:  mapacolor.pm
#
#  DESCRIPTION:  Colorea el mapa de los prefijos de Espa�a con el patron que se indique
#
#       AUTHOR:  Reinoso G.
#===============================================================================

package mapacolor;


use strict;
use warnings;
use Carp;
use List::Util qw[min max];
use ColorUtils qw( :gradients );

# Poblaci�n a 1 de Enero de 2010. Fuente: INE.
my %prefijos = (
      91  => { Provincia => 'Madrid',         Poblacion => 6386932 },
      920 => { Provincia => '�vila',          Poblacion => 171680 },
      921 => { Provincia => 'Segovia',        Poblacion => 164864 },
      922 => { Provincia => 'Tenerife',       Poblacion => 899833 + 86996 + 22769 + 10892},
      923 => { Provincia => 'Salamanca',      Poblacion => 354608 },
      924 => { Provincia => 'Badajoz',        Poblacion => 688777 },
      925 => { Provincia => 'Toledo',         Poblacion => 689635 },
      926 => { Provincia => 'Ciudad Real',    Poblacion => 527273 },
      927 => { Provincia => 'C�ceres',        Poblacion => 413633 },
      928 => { Provincia => 'Las Palmas',     Poblacion => 838397 + 103167 + 141938},
      93  => { Provincia => 'Barcelona',      Poblacion => 5487935 },
      941 => { Provincia => 'La Rioja',       Poblacion => 321702 },
      942 => { Provincia => 'Cantabria',      Poblacion => 589235 },
      943 => { Provincia => 'Guip�zcoa',      Poblacion => 705968 },
      945 => { Provincia => '�lava',          Poblacion => 313809 },
      947 => { Provincia => 'Burgos',         Poblacion => 373672 },
      948 => { Provincia => 'Navarra',        Poblacion => 630598 },
      949 => { Provincia => 'Guadalajara',    Poblacion => 246151 },
      94  => { Provincia => 'Vizcaya',        Poblacion => 1152658 },
      950 => { Provincia => 'Almer�a',        Poblacion => 684426 },
      952 => { Provincia => 'M�laga/Melilla', Poblacion => 1593068 + 73.480 },
      953 => { Provincia => 'Ja�n',           Poblacion => 669782 },
      95  => { Provincia => 'Sevilla',        Poblacion => 1900224 },
      956 => { Provincia => 'C�diz/Ceuta',    Poblacion => 1230594 + 78.674 },
      957 => { Provincia => 'C�rdoba',        Poblacion => 803998 },
      958 => { Provincia => 'Granada',        Poblacion => 907428 },
      959 => { Provincia => 'Huelva',         Poblacion => 513403 },
      964 => { Provincia => 'Castell�n',      Poblacion => 602301 },
      967 => { Provincia => 'Albacete',       Poblacion => 400891 },
      968 => { Provincia => 'Murcia',         Poblacion => 1446520 },
      969 => { Provincia => 'Cuenca',         Poblacion => 217263 },
      96  => { Provincia => 'Alicante/Valencia', Poblacion => 2575362 + 1917012 },
      971 => { Provincia => 'Baleares',       Poblacion => 1095426 },
      972 => { Provincia => 'Gerona',         Poblacion => 747782 },
      973 => { Provincia => 'L�rida',         Poblacion => 436402 },
      974 => { Provincia => 'Huesca',         Poblacion => 228409 },
      975 => { Provincia => 'Soria',          Poblacion => 95101 },
      976 => { Provincia => 'Zaragoza',       Poblacion => 970313 },
      977 => { Provincia => 'Tarragona',      Poblacion => 803331 },
      978 => { Provincia => 'Teruel',         Poblacion => 146751 },
      979 => { Provincia => 'Palencia',       Poblacion => 173306 },
      980 => { Provincia => 'Zamora',         Poblacion => 195665 },
      981 => { Provincia => 'La Coru�a',      Poblacion => 1145488 },
      982 => { Provincia => 'Lugo',           Poblacion => 355195 },
      983 => { Provincia => 'Valladolid',     Poblacion => 532535 },
      986 => { Provincia => 'Pontevedra',     Poblacion => 959764 },
      987 => { Provincia => 'Le�n',           Poblacion => 500169 },
      988 => { Provincia => 'Orense',         Poblacion => 335642 },
      98  => { Provincia => 'Asturias',       Poblacion => 1085289 },
#	xxx =>   'Desconocido',
	);


# Para transformar un gradiente de la p�gina
# http://local.wasp.uwa.edu.au/~pbourke/texture_colour/colourramp/ 
# a este formato se usa grad2perl.pl
my $blue_green_red = [
[  0,  0,255], [  0,  3,255], [  0,  7,255], [  0, 11,255],
[  0, 15,255], [  0, 19,255], [  0, 23,255], [  0, 27,255],
[  0, 31,255], [  0, 35,255], [  0, 39,255], [  0, 43,255],
[  0, 47,255], [  0, 51,255], [  0, 55,255], [  0, 59,255],
[  0, 63,255], [  0, 67,255], [  0, 71,255], [  0, 75,255],
[  0, 79,255], [  0, 83,255], [  0, 87,255], [  0, 91,255],
[  0, 95,255], [  0, 99,255], [  0,103,255], [  0,107,255],
[  0,111,255], [  0,115,255], [  0,119,255], [  0,123,255],
[  0,127,255], [  0,132,255], [  0,135,255], [  0,140,255],
[  0,143,255], [  0,148,255], [  0,151,255], [  0,156,255],
[  0,159,255], [  0,164,255], [  0,167,255], [  0,172,255],
[  0,175,255], [  0,180,255], [  0,183,255], [  0,188,255],
[  0,191,255], [  0,196,255], [  0,199,255], [  0,204,255],
[  0,207,255], [  0,212,255], [  0,215,255], [  0,220,255],
[  0,223,255], [  0,228,255], [  0,231,255], [  0,236,255],
[  0,239,255], [  0,244,255], [  0,247,255], [  0,252,255],
[  0,255,254], [  0,255,249], [  0,255,246], [  0,255,241],
[  0,255,238], [  0,255,233], [  0,255,230], [  0,255,225],
[  0,255,222], [  0,255,217], [  0,255,214], [  0,255,209],
[  0,255,206], [  0,255,201], [  0,255,198], [  0,255,193],
[  0,255,190], [  0,255,185], [  0,255,182], [  0,255,177],
[  0,255,174], [  0,255,169], [  0,255,166], [  0,255,161],
[  0,255,158], [  0,255,153], [  0,255,150], [  0,255,145],
[  0,255,142], [  0,255,137], [  0,255,134], [  0,255,129],
[  0,255,126], [  0,255,122], [  0,255,118], [  0,255,114],
[  0,255,110], [  0,255,106], [  0,255,102], [  0,255, 98],
[  0,255, 94], [  0,255, 90], [  0,255, 86], [  0,255, 82],
[  0,255, 78], [  0,255, 74], [  0,255, 70], [  0,255, 66],
[  0,255, 61], [  0,255, 57], [  0,255, 53], [  0,255, 49],
[  0,255, 45], [  0,255, 41], [  0,255, 37], [  0,255, 33],
[  0,255, 29], [  0,255, 25], [  0,255, 21], [  0,255, 17],
[  0,255, 13], [  0,255,  9], [  0,255,  5], [  0,255,  1],
[  1,255,  0], [  5,255,  0], [  9,255,  0], [ 13,255,  0],
[ 17,255,  0], [ 21,255,  0], [ 25,255,  0], [ 29,255,  0],
[ 33,255,  0], [ 37,255,  0], [ 41,255,  0], [ 45,255,  0],
[ 49,255,  0], [ 53,255,  0], [ 57,255,  0], [ 61,255,  0],
[ 66,255,  0], [ 70,255,  0], [ 74,255,  0], [ 78,255,  0],
[ 82,255,  0], [ 86,255,  0], [ 90,255,  0], [ 94,255,  0],
[ 98,255,  0], [102,255,  0], [106,255,  0], [110,255,  0],
[114,255,  0], [118,255,  0], [122,255,  0], [126,255,  0],
[129,255,  0], [134,255,  0], [137,255,  0], [142,255,  0],
[145,255,  0], [150,255,  0], [153,255,  0], [158,255,  0],
[161,255,  0], [166,255,  0], [169,255,  0], [174,255,  0],
[177,255,  0], [182,255,  0], [185,255,  0], [190,255,  0],
[193,255,  0], [198,255,  0], [201,255,  0], [206,255,  0],
[209,255,  0], [214,255,  0], [217,255,  0], [222,255,  0],
[225,255,  0], [230,255,  0], [233,255,  0], [238,255,  0],
[241,255,  0], [246,255,  0], [249,255,  0], [254,255,  0],
[255,252,  0], [255,247,  0], [255,244,  0], [255,239,  0],
[255,236,  0], [255,231,  0], [255,228,  0], [255,223,  0],
[255,220,  0], [255,215,  0], [255,212,  0], [255,207,  0],
[255,204,  0], [255,199,  0], [255,196,  0], [255,191,  0],
[255,188,  0], [255,183,  0], [255,180,  0], [255,175,  0],
[255,172,  0], [255,167,  0], [255,164,  0], [255,159,  0],
[255,156,  0], [255,151,  0], [255,148,  0], [255,143,  0],
[255,140,  0], [255,135,  0], [255,132,  0], [255,127,  0],
[255,123,  0], [255,119,  0], [255,115,  0], [255,111,  0],
[255,107,  0], [255,103,  0], [255, 99,  0], [255, 95,  0],
[255, 91,  0], [255, 87,  0], [255, 83,  0], [255, 79,  0],
[255, 75,  0], [255, 71,  0], [255, 67,  0], [255, 63,  0],
[255, 59,  0], [255, 55,  0], [255, 51,  0], [255, 47,  0],
[255, 43,  0], [255, 39,  0], [255, 35,  0], [255, 31,  0],
[255, 27,  0], [255, 23,  0], [255, 19,  0], [255, 15,  0],
[255, 11,  0], [255,  7,  0], [255,  3,  0], [255,  0,  0],
];

register_gradient( 'blue_green_red', $blue_green_red );

return 1;


#===  FUNCTION  ================================================================
#      PURPOSE:  Colorear el mapa en base a los valores, de acuerdo a un gradiente
#   PARAMETERS:  hashref {prefijo -> 0<=val<=1} , $mapa_salida , [$gradiente | heat] , [$minGrad | 0] , [$maxGrad | 1] , [$mapa_entrada | prov_prefijos.png] , [$color_null | ffffff]
#                $minGrad y $maxGrad son el l�mite m�ximo y m�nimo del gradiente que se van a usar
#      RETURNS:  Nada
#  DESCRIPTION:  Llama a prefs_fill_map_with_color para hacer el remplazo. Los colores se indican en hex ffffff.
#===============================================================================
sub prefs_fill_map_with_gradient {
	my $replace       = shift || croak "Uso incorrecto de la funci�n prefs_fill_map_with_gradient: se necesitan par�metros.\n";
	my $to_map        = shift || croak "Se debe especificar un archivo de salida.\n";
	my $gradname      = shift || 'heat';
	my $minGrad       = shift || 0;
	my $maxGrad       = shift || 1;
	my $from_map      = shift || 'prov_prefijos.png';
	my $default_color = shift || "#ffffff";
	my $anotacion     = shift || "";

	my $maxval = $replace->{(sort {$replace->{$a} <=> $replace->{$b}} keys %$replace)[-1]};
#	print "$maxval\n";

	my %colors;
	$colors{$_}  = defined $replace->{$_} ? grad2rgb( $gradname, $replace->{$_}/$maxval * ($maxGrad - $minGrad) + $minGrad) : $default_color for keys %prefijos;
	prefs_fill_map_with_color(\%colors, $to_map, $from_map, $default_color, $anotacion);
}


#===  FUNCTION  ================================================================
#      PURPOSE:  Colorear el mapa con los colores asignados
#   PARAMETERS:  hashref {prefijo -> color_nuevo} , $mapa_salida , [$mapa_entrada | prov_prefijos.png] , [$color_null | ffffff]
#      RETURNS:  Nada
#  DESCRIPTION:  Llama a convert para hacer el remplazo. Los colores se indican en hex ffffff.
#     COMMENTS:  Para saber la longitud m�xima de la linea de comandos se puede usar
#                echo $(( $(getconf ARG_MAX) - $(env | wc -c) ))
#===============================================================================
sub prefs_fill_map_with_color {
	my $replace       = shift || croak "Uso incorrecto de la funci�n prefs_fill_map_with_color: se necesitan par�metros.\n";
	my $to_map        = shift || croak "Se debe especificar un archivo de salida.\n";
	my $from_map      = shift || 'prov_prefijos.png';
	my $default_color = shift || "#ffffff";
	my $anotacion     = shift || "";

	my %colors;
	$colors{$_}  = defined $replace->{$_} ? $replace->{$_} : $default_color for keys %prefijos;

	my $convert_cmd = '';
	$convert_cmd .= "convert $from_map ";
	$convert_cmd .= sprintf(' -fill \%06s -opaque \#%06d ', $colors{$_}, $_) for keys %colors;
	$convert_cmd .= " -font helvetica -pointsize 30 -gravity northeast -fill black -annotate 0x0+20+20 '$anotacion' ";
	$convert_cmd .= $to_map;

	 print $convert_cmd,"\n";

	`$convert_cmd`;
}


=head1 NAME

mapacolor - Colorea mapas. De momento s�lo los prefijos de Espa�a.

=head1 SYNOPSIS

  use mapacolor;

  my %valores;
  $valores{pref1} = ...
  $valores{pref2} = ...

  mapacolor::prefs_fill_map_with_gradient(\%valores,           # hash de valores
                                          $outfile,            # archivo salida
                                          'blue_green_red',    # nombre del gradiente
                                          0.0,                 # l�mite inferior del gradeinte
                                          1,                   # l�mite superior del gradiente
                                          undef,               # mapa origen
                                          '0a0d0f',            # color de fondo
                                          $anotacion);         # texto de titulo


=head1 DESCRIPTION

Colorea mapas con un gradiente segun los valores que se indiquen. De momento s�lo tiene el mapa de
los prefijos de espa�a.

=head2 Funciones

=over 4

=item * prefs_fill_map_with_gradient($valores, $outfile, $gradname, $gradmax, $gradmin, $map, $bgcolor, $title)

Genera el mapa coloreado a partir de los par�metros. 


B<valores>: Referencia a hash. La clave es un prefijo, el valor una cantidad. Se normaliza para que la 
cantidad m�xima coincida con el color m�ximo del gradiente.

B<outfile>: Archivo de salida.

B<gradname>: Nombre del gradiente. De momento s�lo est� registrado el gradiente 'blue_green_red'
y el resto que tiene registrados Graphics::ColorUtils.

B<gradmax>: Tope superior del gradiente. Por defecto es 1.

B<gradmin>: Tope inferior del gradiente. Por defecto es 0.

B<map>: Mapa plantilla para colorear, por defecto es el 'prov_prefijos.png'.

B<bgcolor>: Color de fondo para las regiones que no tengan datos. Por defecto es blanco.
B<title>: Titlo que se incluir� en la esquina superior derecha del mapa.

=back

=head1 AUTHOR

Reinoso G.

=head1 SEE ALSO

Graphics::ColorUtils(3pm)

=cut
