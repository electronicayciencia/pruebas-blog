if [ -z $4 ]
then
	echo "Uso: $0 in1.pdf in2.pdf in3.pdf output.pdf"
	exit 1
fi

tmp=`mktemp`

pdftk $1    stamp $2 output $tmp
pdftk $tmp  stamp $3 output $4
rm $tmp
