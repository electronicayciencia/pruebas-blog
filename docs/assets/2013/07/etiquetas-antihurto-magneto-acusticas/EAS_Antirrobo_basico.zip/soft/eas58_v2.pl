#!/usr/bin/perl 
#===============================================================================
#
#		 FILE:  eas58
#
#		USAGE:  ./eas58.pl [fichero.wav]
#				Si no se da fichero.wav se lee del dispositivo de grabaci�n hw:0,0.
#
#  DESCRIPTION:  Avisa cuando se detecta la alarma.
#
#                Procedimiento:
#                    Aplicar filtro paso alto
#                    Quedarnos con los picos
#                    Calcular la duraci�n del pulso
#
# REQUIREMENTS:  sox
#		NOTES:  http://electronicayciencia.blogspot.com
#	   AUTHOR:  Reinoso Guzm�n
#	  VERSION:  1.0
#	  CREATED:  12/06/13 12:16:09
#===============================================================================

use strict;
use warnings;
use Tk;
use Tk::ProgressBar;
use Tk::ErrorDialog;


# PARAMETROS
###########################################################
my $srate  = 48000;   # Frecuencia de muestreo
my $ampl   = 500;     # % de amplificacion
my $frec   = 4000;    # Frecuencia central de excitaci�n
my $v_sql  = 5;       # Umbral de ruido
my $d_rep  = 5;       # ms Tiempo de duraci�n del pulso en reposo
my $t_max  = 6;       # Dispara la alarma si el pulso dura m�s que $t_max

# VARIABLES
###########################################################
$| = 1;
my $last_status = 0;  # estado actual
my $last_alarm = -1;  # momento de la �ltima alarma
my $file = $ARGV[0];  # fichero de entrada
my $datafh;           # manejador del fichero de entrada
my $mw;               # Interfaz gr�fica 
my $mwlabel;          # Manejador de la etiqueta gr�fica
my $mwpbar;           # Manejador de la barra del nivel
my $mwpbar_palo;      # Manejador de la barra de palo
my $mwloop;           # Manejador del bucle de lectura


# LEER MUESTRAS
###########################################################
$SIG{CHLD} = "IGNORE";
$SIG{PIPE} = sub {print STDERR "Error en la captura de sonido.\n"; exit};

if ( $file and !-e $file ) {
    die "El fichero $file no existe o no se puede leer.\n";
}

if ($file) {
    open $datafh, "sox $file -t dat - |" or die "Error: $!\n";
}
else {
    $ENV{AUDIODEV} = "hw:0,0";
    open $datafh, "rec -q -c 1 -r $srate  -t dat - |"
      or die "Error: $!\n";
}


# INTERFAZ GR�FICA
###########################################################
$mw = MainWindow->new( );
$mw->title("Antirrobo electronicayciencia EAS-58kHz");

# Tk requiere cancelar el bucle antes de salir
$mw->protocol(WM_DELETE_WINDOW => \&clean_exit);

# Progressbar de palo, s�lo indicativa
$mwpbar_palo = $mw->ProgressBar(
        -width => 3,
        -from => 0,
        -to => 2*$t_max,
		-gap => 0,
        -colors => [0, 'green', $d_rep * 0.8, 'yellow' , $t_max, 'red'],
        -value => 100,
    )->pack(-fill => 'x');

$mwpbar = $mw->ProgressBar(
        -width => 15,
        -from => 0,
        -to => 2*$t_max,
        -blocks => 120,
        -colors => [0, 'green', $d_rep * 0.8, 'yellow' , $t_max, 'red'],
#        -variable => \$v, # consume demasiados recursos
    )->pack(-fill => 'x');

$mw->Label( -text => 'Detector basado en el tiempo que dura el eco')->pack;

#$mw->Label( 
#		-text   => 'http://electronicayciencia.blogspot.com',
#		-anchor => 'e'
#	)->pack( -side => 'bottom', -fill => 'x');

my $guardia = $mw->Photo(-file => "Policeman-wbilly-club.gif");
$mw->Label(-image => $guardia)->pack( -side => 'right' );

$mw->Scale( 
		-from         => 0,
		-to           => 10,
		-orient       => 'horizontal',
		-resolution   => 0.1,
		-width        => 20,
		-showvalue    => 1,
		-sliderlength => 40,
		-label        => 'Squelch',
		-variable     => \$v_sql,
#		-command      => \&updatebars,
	)->pack( 
		-padx => 10,
		-pady => 10,
		-side => 'top',
		-fill => 'x'
	);

$mwlabel = $mw->Label(
		-text         => "A L A R M A",
		-font         => '-*-Helvetica-Bold-R-Normal-*-*-400-*-*-*-*-*-*',
		-anchor       => 'center',
		-foreground   => 'black',
		-relief       => 'raised',
		-borderwidth  => 8,
		-padx         => 20,
		-pady         => 10,
		-background   => 'grey'
	)->pack( 
		-padx => 20,
		-pady => 20,
		-fill => 'x',
		-expand => 1);


$mw->Popup;    # centrar la ventana
$mwloop = $mw->after(1, \&get_samples);
MainLoop;


#get_samples();

# BUCLE DE PROCESO
###########################################################
sub get_samples {
	my $last_refresh = 0;
	my $x1 = 0;     # muestra anterior, para hacer el filtro FIR
	my $t_silencio_start = 0;
	my $t_pulso_start = 0;
	my $tau = 1/(2*$frec)*3; # pueden faltar hasta 3 picos, le damos un margen
	my $y;
	my $duracion_pulso = 0;
	while (my $linea = <$datafh>) {
		next unless $linea;

		my (undef, $t, $x) = split /\s+/, $linea;
		next unless $t =~ /^[-?\d\.]+$/; # Saltar las lineas no num�ricas.
		next unless $x =~ /^[-?\d\.]+$/; 

		# Procesado de la se�al
		# Aplicamos paso alto restando la lectura anterior
		# Rectificamos
		# Si la se�al tiene frecuencia F, se espera que haya picos cada 
		# tau = 1/(2*F) segundos
		# En el momento que transcurra tau sin superar el umbral de ruido
		# calculamos la duraci�n del pulso.
		# Para duraciones superiores a $t_max disparamos la alarma.
		$x = $ampl*$x;  # amplificador
		
		$y = $x-$x1;     # filtro
		$x1 = $x;

		$y = abs($y);   # rectificador

		#printf("%3.4fs -> %3.2f\n", $t, $y);
		
		if ($y > $v_sql) {
			#printf("%3.2fs -> %s\n", $t, "Comienza pulso");
			$t_pulso_start = $t if not $t_pulso_start;
			undef $t_silencio_start;
		}

		if (defined $t_silencio_start and $t - $t_silencio_start > 2*$d_rep) {
			$duracion_pulso = 0;
		}

		if ($y < $v_sql and not $t_silencio_start) {
			$t_silencio_start = $t;
			#printf("%3.2fs -> Comienza silencio (sigue pulso %3.3fs)\n", $t, $t-$t_pulso_start);
		}

#		printf("T: %3.4fs Tpulso: %4dus Tsilencio: %4dus tau: %3dus\n",
#			$t,
#			1000000 * ($t-$t_pulso_start),
#			1000000 * ($t-$t_silencio_start),
#			1000000 * $tau,
#		);

		# Actualizar la etiqueta cuando termina cada pulso
		if (defined $t_pulso_start and defined $t_silencio_start and $t - $t_silencio_start > $tau) {
			$duracion_pulso = $t_silencio_start - $t_pulso_start;
			undef $t_silencio_start;
			undef $t_pulso_start;

			#printf("Sample %d: %3.2fs -> Acaba pulso, duraci�n: %3.2fms\n", $., $t, $duracion_pulso*1000);


			# Determinar si hay que actualizar la etiqueta
			if ($duracion_pulso > $t_max/1000 and $last_status == 0) {
				$mwlabel->configure(-background   => 'red');
				$last_alarm = $t;
				#printf("$.: %3.2fs -> Activada (duraci�n %3dms)\n", $t, $duracion_pulso*1000);
				fork() == 0 and exec 'play','-q','pitido3s.wav';
				$last_status = 1;
			}
			elsif ($duracion_pulso < $t_max/1000 and $last_status == 1 and $t - $last_alarm > 3) {
				$mwlabel->configure(-background   => 'grey');
				#printf("$.: %3.2fs -> DESActivada (duraci�n %3dms)\n", $t, $duracion_pulso*1000);
				$last_status = 0;
			}
			
			$mw->update;
		}

		# Tenemos que refrescar nosotros, que ya no estamos en mainloop.
		if ($t - $last_refresh > 0.01) {
			$mwpbar->configure( -value => 1000*$duracion_pulso );
			$mw->update;
			#printf("$.: %3.2fs -> Refresh (%d)\n", $t, 1000*$duracion_pulso);
			$last_refresh = $t;
		}
	}

	clean_exit();
}

sub clean_exit {
   $mwloop->cancel;
   $mw->destroy;
   exit(0);
}
