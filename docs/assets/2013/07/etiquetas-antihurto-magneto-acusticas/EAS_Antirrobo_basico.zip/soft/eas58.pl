#!/usr/bin/perl 
#===============================================================================
#
#		 FILE:  eas58
#
#		USAGE:  ./eas58.pl [fichero.wav]
#				Si no se da fichero.wav se lee del dispositivo de grabaci�n hw:0,0.
#
#  DESCRIPTION:  Avisa cuando se detecta la alarma.
#
#                Procedimiento:
#                    Multiplicar por un n�mero (amplificador)
#                    Tomar valor absoluto (rectificador onda completa)
#                    Media movil exponencial (filtro paso bajo)
#
# REQUIREMENTS:  sox
#		NOTES:  http://electronicayciencia.blogspot.com
#	   AUTHOR:  Reinoso Guzm�n
#	  VERSION:  1.0
#	  CREATED:  11/06/13 12:16:09
#===============================================================================

use strict;
use warnings;
use Tk;
use Tk::ProgressBar;
use Tk::ErrorDialog;


# PARAMETROS
###########################################################
my $srate  = 48000;   # Sampling rate
my $alpha  = 0.0002;  # Coeficiente de filtrado
my $ampl   = 100;     # % de amplificacion
my $v_max  = 50;      # Umbral de alarma


# VARIABLES
###########################################################
$| = 1;
my $retardo = 0.05;   # Tiempo de actualizaci�n en s
my $last_t  = 0;      # tiempo de la ultima actualizacion
my $last_status = 0;  # estado actual
my $last_alarm = -1;  # momento de la �ltima alarma
my $file = $ARGV[0];  # fichero de entrada
my $datafh;           # manejador del fichero de entrada
my $v = 0;            # Se�al promediada
my $mw;               # Interfaz gr�fica 
my $mwlabel;          # Manejador de la etiqueta gr�fica
my $mwpbar;           # Manejador de la barra del nivel
my $mwpbar_palo;      # Manejador de la barra de palo
my $mwloop;           # Manejador del bucle de lectura


# LEER MUESTRAS
###########################################################
$SIG{CHLD} = "IGNORE";
$SIG{PIPE} = sub {print STDERR "Error en la captura de sonido.\n"; exit};

if ( $file and !-e $file ) {
    die "El fichero $file no existe o no se puede leer.\n";
}

if ($file) {
    open $datafh, "sox $file -t dat - |" or die "Error: $!\n";
}
else {
    #$ENV{AUDIODEV} = "hw:0,0";
    open $datafh, "rec -q -c 1 -r $srate  -t dat - |"
      or die "Error: $!\n";
}


# INTERFAZ GR�FICA
###########################################################
$mw = MainWindow->new( );
$mw->title("Antirrobo electronicayciencia EAS-58kHz");

# Tk requiere cancelar el bucle antes de salir
$mw->protocol(WM_DELETE_WINDOW => \&clean_exit);

# Progressbar de palo, s�lo indicativa
$mwpbar_palo = $mw->ProgressBar(
        -width => 3,
        -from => 0,
        -to => 100,
		-gap => 0,
        -colors => [0, 'green', $v_max * 0.8, 'yellow' , $v_max, 'red'],
        -value => 100,
    )->pack(-fill => 'x');

$mwpbar = $mw->ProgressBar(
        -width => 15,
        -from => 0,
        -to => 100,
        -blocks => 120,
        -colors => [0, 'green', $v_max * 0.8, 'yellow' , $v_max, 'red'],
#        -variable => \$v, # consume demasiados recursos
    )->pack(-fill => 'x');

$mw->Label( -text => 'Detector basado en el cambio de la intensidad media')->pack;

#$mw->Label( 
#		-text   => 'http://electronicayciencia.blogspot.com',
#		-anchor => 'e'
#	)->pack( -side => 'bottom', -fill => 'x');

my $guardia = $mw->Photo(-file => "Policeman-wbilly-club.gif");
$mw->Label(-image => $guardia)->pack( -side => 'right' );

$mw->Scale( 
		-from         => 1,
		-to           => 100,
		-orient       => 'horizontal',
		-resolution   => 1,
		-width        => 20,
		-showvalue    => 0,
		-sliderlength => 40,
		-label        => 'Umbral de disparo',
		-variable     => \$v_max,
		-command      => \&updatebars,
	)->pack( 
		-padx => 10,
		-pady => 10,
		-side => 'top',
		-fill => 'x'
	);

$mwlabel = $mw->Label(
		-text         => "A L A R M A",
		-font         => '-*-Helvetica-Bold-R-Normal-*-*-400-*-*-*-*-*-*',
		-anchor       => 'center',
		-foreground   => 'black',
		-relief       => 'raised',
		-borderwidth  => 8,
		-padx         => 20,
		-pady         => 10,
		-background   => 'grey'
	)->pack( 
		-padx => 20,
		-pady => 20,
		-fill => 'x',
		-expand => 1);


$mw->Popup;    # centrar la ventana
$mwloop = $mw->after(1, \&get_samples);
MainLoop;


# BUCLE DE PROCESO
###########################################################
sub get_samples {
	while (my $linea = <$datafh>) {
		next unless $linea;

		my (undef, $t, $x) = split /\s+/, $linea;
		next unless $t =~ /^[-?\d\.]+$/; # Saltar las lineas no num�ricas.
		next unless $x =~ /^[-?\d\.]+$/; 

		# Procesado de la se�al
		$x = $ampl*$x;  # amplificador
		$x = abs($x);   # rectificador
		$v = $v + $alpha * ($x - $v); # condensador de filtrado

		$v > $v_max and $last_alarm = $t;

		# Actualizar s�lo cada n segundos
		next if $t - $last_t < $retardo;
		$last_t = $t;
		
		#printf ("%3.2fs: %1.3f\n", $t, $x, $v);
		$mwpbar->configure( -value => $v );

		# Determinar si hay que actualizar la etiqueta
		if ($v > $v_max and $last_status == 0) {
			$mwlabel->configure(-background   => 'red');
			#printf("%3.2fs -> %s\n", $t, "Activada!");
			fork() == 0 and exec 'play','-q','pitido3s.wav';
			$last_status = 1;
		}
		elsif ($v < $v_max and $last_status == 1 and $t - $last_alarm > 3) {
			$mwlabel->configure(-background   => 'grey');
			#printf("%3.2fs -> %s\n", $t, "DESActivada!");
			$last_status = 0;
		}
		
		$mw->update;
	}

	clean_exit();
}

sub updatebars {
	$mwpbar_palo->configure(
		-colors => [0, 'green', $v_max * 0.8, 'yellow' , $v_max, 'red']);
	$mwpbar->configure(
		-colors => [0, 'green', $v_max * 0.8, 'yellow' , $v_max, 'red']);
	#$mw->update no sirve para actualizar
	Tk::ProgressBar::_layoutRequest($mwpbar_palo, 1);
	Tk::ProgressBar::_layoutRequest($mwpbar, 1);
}

sub clean_exit {
   $mwloop->cancel;
   $mw->destroy;
   exit(0);
}
