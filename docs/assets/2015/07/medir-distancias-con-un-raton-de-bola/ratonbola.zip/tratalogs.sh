#!/bin/bash
# Obtiene del fichero de logs la posicion en el eje Y cambiada de signo
# Adicionalmente extrae a un fichero a parte las posiciones con marca

file=$1

if [ -z "$file" ]
then
	echo "Uso: $0 fichero_de_log"
	exit
fi

if [ ! -f $file ]
then
	echo $file no es un fichero valido o no existe.
	exit
fi

filename=${file%%.*}

cat $file | awk '$4~/mark/ {print $1,-$3}' > ${filename}_mark.dat
cat $file | awk '{print $1,-$3}' > ${filename}_pos.dat

