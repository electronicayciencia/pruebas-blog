% Eliminar posiciones duplicadas del vector a

d = diff(a);
% S�lo nos interesa cuando el diff de la posici�n ~0
% Y el primer valor siempre nos lo quedamos
d = [1; d(:,2)];
a(~d,:) = [];