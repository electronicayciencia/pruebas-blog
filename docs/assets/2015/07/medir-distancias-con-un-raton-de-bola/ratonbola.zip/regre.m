file = 'logs/10cm_01_mark.dat';
fprintf('\nFichero: %s\n' , file)
a = load(file);
% Tiempo , Marca , Pulsos
a = [a(:,1) (0:length(a)-1)' a(:,2)];
X = [ones(length(a), 1) a(:,2)];
theta = (pinv(X'*X))*X'*a(:,3);
fprintf('Pulsos por cm: %.1f\n', theta(2))

plot(a(:,2),a(:,3), '+', a(:,2), X*theta);

e = sum((a(:,3)-X*theta).^2)/length(a);
fprintf('Error de regresion (cm): %.3f\n\n', e/theta(2))


% Resultados de la regresi�n (pulsos/cm)
%  146.048 ( 1cm 1)
%  144.318 ( 1cm 2)
% 1450.857 (10cm 1)
% 1450.679 (10cm 2)

