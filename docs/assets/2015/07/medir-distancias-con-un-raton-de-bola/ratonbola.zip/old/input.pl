#!/usr/bin/perl 
#===============================================================================
#
#         FILE:  input.pl
#
#        USAGE:  ./input.pl
#
#  DESCRIPTION:  Medidor de distancias con el ratón
#
#
#      OPTIONS:  ---
# REQUIREMENTS:  ---
#         BUGS:  ---
#        NOTES:  Consultar la documentación de Linux::Input
#       AUTHOR:  Reinoso G.
#      COMPANY:
#      VERSION:  1.0
#      CREATED:  28/12/13 17:25:49
#     REVISION:  ---
#===============================================================================

use strict;
use warnings;
use Linux::Input;
use Data::Dumper;
use Switch;

# Hace evtest para ver de dónde vienen los eventos
# sudo evtest.pl /dev/input/event*
my $dev = '/dev/input/event6';

$| = 0;

# --- Eventos ---
my $EV_SYN     = 0x00;
my $EV_KEY     = 0x01;
my $EV_REL     = 0x02;
my $EV_ABS     = 0x03;
my $EV_MSC     = 0x04;
my $REL_X      = 0x00;
my $REL_Y      = 0x01;
my $ABS_X      = 0x00;
my $ABS_Y      = 0x01;
my $BTN_LEFT   = 0x110;
my $BTN_RIGHT  = 0x111;
my $BTN_MIDDLE = 0x112;

# --- Estado ---
my $DEBUG = 0;
my $X     = 0;
my $Y     = 0;
my $updated =  0;    # indica si alguna variable ha sido actualizada a un nuevo valor
my $rec = 0;    # indica si estamos grabando los movimientos

# --- Bucle ---
my $js1 = Linux::Input->new($dev);

while (1) {
    while ( my @events = $js1->poll(0.001) ) {
        foreach my $event (@events) {

            if (    $event->{type} == $EV_KEY
                and $event->{code} == $BTN_RIGHT
                and $event->{value} )
            {
                $rec = 1 - $rec;
                print STDERR "Grabando: $rec\n";

                if ($rec) {
                    $X = 0;
                    $Y = 0;
                    $updated++;
                }
            }

            if ( $event->{type} == $EV_REL) {
                if ( $event->{code} == $REL_X ) {
                    $X += $event->{value};
                    $updated++;
                }

                if ( $event->{code} == $REL_Y ) {
                    $Y += $event->{value};
                    $updated++;
                }
            }

            if ( $event->{type} == $EV_SYN and $updated and $rec ) {
                printf "%.3f\t%d\t%d\n",
                  $event->{tv_sec} + $event->{tv_usec} * 1E-6,
                  $X,
                  $Y;

                $updated = 0;
            }

            if ($DEBUG) {
                $DB::single = 2;
                $event->{type} == 0
                  and print "----------------\n"
                  and next;    # EV_SYN
                print Dumper( \$event );
            }
        }
    }
}

