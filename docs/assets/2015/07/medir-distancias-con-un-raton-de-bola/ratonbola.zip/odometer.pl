#!/usr/bin/perl 
#===============================================================================
#
#		  FILE:  odometer.pl
#
#		 USAGE:  ./odometer.pl id_event id_xinput
#
#  DESCRIPTION:  Medidor de distancias con el ratón.
#
#
#	   OPTIONS:  ---
# REQUIREMENTS:  ---
#		  BUGS:  ---
#		 NOTES:  Consultar la documentación de Linux::Input
#		AUTHOR:  Reinoso G.
#	   COMPANY:
#	   VERSION:  2.0
#	   CREATED:  28/12/13 17:25:49
#	  REVISION:  01/07/15 18:10:12
#===============================================================================

use strict;
use warnings;
use Linux::Input;
use Switch;
use Time::HiRes;


use constant {
	EV_SYN	   => 0x00,
	EV_KEY	   => 0x01,
	EV_REL	   => 0x02,
	EV_ABS	   => 0x03,
	EV_MSC	   => 0x04,

	REL_X	   => 0x00,
	REL_Y	   => 0x01,

	ABS_X	   => 0x00,
	ABS_Y	   => 0x01,

	BTN_LEFT   => 0x110,
	BTN_RIGHT  => 0x111,
	BTN_MIDDLE => 0x112,
};

my $polltime = 0.001; # segs
my $X	= 0;
my $Y	= 0;
my $logprefix = "/tmp/log_odometer";
my $logtimer  = 0.1; # segundos entre cada registro de estado


my $logfile;
my $logfh;
my $rec = 0;	# indica si estamos grabando los movimientos

# --- Bucle ---
$| = 1;
my $id_event  = $ARGV[0] || usage();
my $id_xinput = $ARGV[1] || usage();

my $device = Linux::Input->new("/dev/input/event$id_event");

x_disable_device($id_xinput);
$SIG{INT} = \&ordered_exit;

print "Pulsa Ctrl+C para terminar la ejecución.\n";

my $t0 = Time::HiRes::time;

while (1) {
	foreach my $ev ($device->poll($polltime)) {
		switch($ev->{type}) {
			case EV_KEY { on_key($ev) }
			case EV_REL { on_rel($ev) }
			case EV_SYN { on_syn($ev) }
		}
	}

	my $t1 = Time::HiRes::time;
	if ($t1 - $t0 >= $logtimer) {
		$t0 = $t1;
		$rec and printf $logfh "%.3f\t%d\t%d\n", $t0, $X, $Y;
	}
}

sub usage {
	print "
Uso: $0 id_dev id_x
  id_dev   número de fichero /dev/input/eventX
  id_x     identificador de dispositivo en Xorg

Para averiguar id_dev basta ejecutar 'evtest.pl /dev/input/event<X>' hasta
dar con el fichero del dispositivo.

Para averiguar id_x basta ejecutar xinput y buscar el id= correspondiente.
";
	exit;
	
}

sub ordered_exit {
	x_enable_device($id_xinput);
	print "\n";
	close $logfh;
	exit; 
}

sub x_disable_device {
	my $id = shift or return;
	`xinput disable $id`;
}

sub x_enable_device {
	my $id = shift or return;
	`xinput enable $id`;
}

# Evento de botón (press or released)
sub on_key {
	my $ev = shift;
	switch ($ev->{code}) {
		case BTN_RIGHT  { on_btn_right($ev)  }
		case BTN_LEFT   { on_btn_left($ev)   }
		case BTN_MIDDLE { on_btn_middle($ev) }
	}
}

# Evento de movimiento relativo
# Los ratones no tienen movimiento absoluto, las tabletas sí
sub on_rel {
	my $ev = shift;
	switch ($ev->{code}) {
		case REL_X { on_rel_x($ev) }
		case REL_Y { on_rel_y($ev) }
	}
}



# --- Funciones de usuario ---
sub on_rel_x {
	my $ev = shift;
	$X += $ev->{value};
}

sub on_rel_y {
	my $ev = shift;
	$Y += $ev->{value};
}

sub on_syn {
	my $ev = shift;
	if ($rec) {
		printf "%.3f\t%d\t%d\n",
			$ev->{tv_sec} + $ev->{tv_usec} * 1E-6,
			$X,
			$Y;
	}
}

# Reinicia las coordenadas
sub on_btn_right {
	my $ev = shift;

	return if $ev->{value} == 0; # sólo actuar en la pulsación

	$rec = 1 - $rec;

	if ($rec) {
		my $rand = int(100 + 900*rand);
		$logfile = $logprefix ."_". $rand . ".log";
		open $logfh, ">>", $logfile or die;
		print STDERR "Grabando: $logfile\n";
		$X = 0;
		$Y = 0;
	}
	else {
		print STDERR "Grabacion terminada: $logfile\n";
		close $logfh;
	}
}

sub on_btn_left {
	my $ev = shift;
	return if $ev->{value} == 0; # sólo actuar en la pulsación
	printf $logfh "%.3f\t%d\t%d\t-mark-\n", Time::HiRes::time, $X, $Y;
	printf STDERR "%.3f\t%d\t%d\t-mark-\n", Time::HiRes::time, $X, $Y;
}

sub on_btn_middle {
	my $ev = shift;

	print "btn_middle not assigned\n";
}
