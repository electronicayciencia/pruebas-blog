% Carga el fichero atwood.log y calcula el ajuste a un movimiento
% uniformemente acelerado (MUA).

a = load('logs/atwood.log');
t = a(:,1);
t = t - t(1);

s = a(:,3);
s = s/145.1; % a cm
s = s/100;   % a m


